<?php

$server = 'localhost';
$user = 'root';
$password = '';
$db = 'galeri';
$dir_gambar = 'C:\xampp\htdocs\anggara\gambar\\';
$url_folder_gambar = 'http://localhost/anggara/gambar/';
?>